import { ApplicationConfig, provideBrowserGlobalErrorListeners } from '@angular/core';
import { provideRouter } from '@angular/router';
import { providePrimeNG } from 'primeng/config';
import { definePreset } from '@primeuix/themes';
import Aura from '@primeuix/themes/aura';
import { provideHttpClient } from '@angular/common/http';

import { routes } from './app.routes';

const PrecisionLogicPreset = definePreset(Aura, {
  primitive: {
    borderRadius: {
      none: '0px',
      xs: '4px',
      sm: '6px',
      md: '8px',
      lg: '12px',
      xl: '16px'
    }
  },
  semantic: {
    primary: {
      50: '#e6f7fa',
      100: '#abedff',
      200: '#84d2e7',
      300: '#54d6f3',
      400: '#008398',
      500: '#006879',
      600: '#004e5c',
      700: '#003943',
      800: '#00252c',
      900: '#001f26',
      950: '#000f14'
    },
    colorScheme: {
      light: {
        surface: {
          0: '#ffffff',
          50: '#f9f9ff',
          100: '#f1f3ff',
          200: '#eaedfa',
          300: '#e5e8f4',
          400: '#dfe2ef',
          500: '#d6dae6',
          600: '#bfc6dc',
          700: '#6f778b',
          800: '#3f4759',
          900: '#171c24',
          950: '#0a0d12'
        }
      }
    }
  }
});

export const appConfig: ApplicationConfig = {
  providers: [
    provideBrowserGlobalErrorListeners(),
    provideRouter(routes),
    provideHttpClient(),
    providePrimeNG({
      theme: {
        preset: PrecisionLogicPreset,
        options: {
          darkModeSelector: false
        }
      }
    })
  ]
};
