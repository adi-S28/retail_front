import { Routes } from '@angular/router';
import { MainLayout } from './layout/main-layout/main-layout';
import { Dashboard } from './features/dashboard/pages/dashboard/dashboard';
import { PromotionList } from './features/promotion/pages/promotion-list/promotion-list';

export const routes: Routes = [
    {
        path:'',
        component:MainLayout,
        children:[
            {
                path:'',
                component:Dashboard
            },
            {
                path:'promotion',
                component:PromotionList
            }
        ]
    }
];
