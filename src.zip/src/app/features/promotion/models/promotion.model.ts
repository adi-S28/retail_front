export interface Promotion{
    promotionId:number;
    name:string;
    discountType:string;
    discountValue:number;
    startDate:string;
    endDate:string;
    applicationScope:string;
    promotionStatus:string;
}