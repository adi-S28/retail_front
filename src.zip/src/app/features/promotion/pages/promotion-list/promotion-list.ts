import { inject, OnInit } from "@angular/core";
import { PromotionService } from "../../services/promotion.service";
import { Component } from "@angular/core";
import { CommonModule } from "@angular/common";
import { Promotion } from "../../models/promotion.model";
import {TableModule} from 'primeng/table';
import { ButtonModule } from "primeng/button";
import {TagModule} from "primeng/tag"


@Component({
  selector: 'app-promotion-list',
  standalone: true,
  imports: [TableModule, ButtonModule, TagModule, CommonModule],
  templateUrl: './promotion-list.html',
  styleUrl: './promotion-list.css'
})

export class PromotionList implements OnInit{

    private promotionService=inject(PromotionService);

    promotions:Promotion[]=[];

    ngOnInit(): void {
        this.loadPromotions();
    }

    loadPromotions():void{
        this.promotions=[
            {
      promotionId: 1,
      name: 'Diwali Sale',
      discountType: 'PERCENTAGE',
      discountValue: 20,
      startDate: '2026-07-20',
      endDate: '2026-07-31',
      applicationScope: 'ALL_PRODUCTS',
      promotionStatus: 'ACTIVE'
    },
    {
      promotionId: 2,
      name: 'Weekend Offer',
      discountType: 'FLAT',
      discountValue: 500,
      startDate: '2026-07-22',
      endDate: '2026-07-25',
      applicationScope: 'ELECTRONICS',
      promotionStatus: 'UPCOMING'
    }
        ];
        // this.promotionService.getAll().subscribe({
        //     next:(data)=>{
        //         console.log(data);
        //         this.promotions = data;

        //     },
        //     error:(err)=>{
        //         console.error(err);
        //     }
            
        // });
    }

}