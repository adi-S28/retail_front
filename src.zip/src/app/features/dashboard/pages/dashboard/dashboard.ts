import { Component } from '@angular/core';
import{CardModule} from 'primeng/card';
import { ButtonModule } from 'primeng/button';
import {DividerModule} from 'primeng/divider';

@Component({
  selector: 'app-dashboard',
  standalone:true,
  imports: [CardModule, ButtonModule, DividerModule],
  templateUrl: './dashboard.html',
  styleUrl: './dashboard.css',
})
export class Dashboard {}
