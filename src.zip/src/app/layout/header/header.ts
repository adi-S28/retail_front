import { Component } from '@angular/core';
import { ButtonDirective } from "primeng/button";

@Component({
  selector: 'app-header',
  imports: [ButtonDirective],
  templateUrl: './header.html',
  styleUrl: './header.css',
})
export class Header {}
